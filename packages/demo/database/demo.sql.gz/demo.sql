-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES
(1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2026-08-20 08:17:10','2026-08-20 08:17:10','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com/\">Gravatar</a>.',0,'1','','comment',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES
(1,'cron','a:5:{i:1787221030;a:2:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1787260630;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1787262430;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1787300230;a:3:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:41:\"wp_privacy_personal_data_cleanup_requests\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','on'),
(2,'siteurl','https://foehn-demo.ddev.site/wp','on'),
(3,'home','https://foehn-demo.ddev.site/wp','on'),
(4,'blogname','Føhn','on'),
(5,'blogdescription','Architecture, portrait and still-life photography. Strasbourg.','on'),
(6,'users_can_register','0','on'),
(7,'admin_email','admin@example.com','on'),
(8,'start_of_week','1','on'),
(9,'use_balanceTags','0','on'),
(10,'use_smilies','1','on'),
(11,'require_name_email','1','on'),
(12,'comments_notify','1','on'),
(13,'posts_per_rss','10','on'),
(14,'rss_use_excerpt','0','on'),
(15,'mailserver_url','mail.example.com','on'),
(16,'mailserver_login','login@example.com','on'),
(17,'mailserver_pass','','on'),
(18,'mailserver_port','110','on'),
(19,'default_category','1','on'),
(20,'default_comment_status','open','on'),
(21,'default_ping_status','open','on'),
(22,'default_pingback_flag','1','on'),
(23,'posts_per_page','10','on'),
(24,'date_format','F j, Y','on'),
(25,'time_format','g:i a','on'),
(26,'links_updated_date_format','F j, Y g:i a','on'),
(27,'comment_moderation','0','on'),
(28,'moderation_notify','1','on'),
(29,'permalink_structure','/%postname%/','on'),
(30,'rewrite_rules','a:146:{s:11:\"projects/?$\";s:27:\"index.php?post_type=project\";s:41:\"projects/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:36:\"projects/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:28:\"projects/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=project&paged=$matches[1]\";s:11:\"^_health/?$\";s:28:\"index.php?foehn_route=health\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:39:\"testimonial/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"testimonial/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"testimonial/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"testimonial/([^/]+)/embed/?$\";s:44:\"index.php?testimonial=$matches[1]&embed=true\";s:32:\"testimonial/([^/]+)/trackback/?$\";s:38:\"index.php?testimonial=$matches[1]&tb=1\";s:40:\"testimonial/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&paged=$matches[2]\";s:47:\"testimonial/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&cpage=$matches[2]\";s:36:\"testimonial/([^/]+)(?:/([0-9]+))?/?$\";s:50:\"index.php?testimonial=$matches[1]&page=$matches[2]\";s:28:\"testimonial/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"testimonial/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"testimonial/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"projects/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"projects/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"projects/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"projects/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"projects/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"projects/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"projects/([^/]+)/embed/?$\";s:40:\"index.php?project=$matches[1]&embed=true\";s:29:\"projects/([^/]+)/trackback/?$\";s:34:\"index.php?project=$matches[1]&tb=1\";s:49:\"projects/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:44:\"projects/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:37:\"projects/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&paged=$matches[2]\";s:44:\"projects/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&cpage=$matches[2]\";s:33:\"projects/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?project=$matches[1]&page=$matches[2]\";s:25:\"projects/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"projects/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"projects/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"projects/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"projects/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"projects/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:52:\"project_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?project_tag=$matches[1]&feed=$matches[2]\";s:47:\"project_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?project_tag=$matches[1]&feed=$matches[2]\";s:28:\"project_tag/([^/]+)/embed/?$\";s:44:\"index.php?project_tag=$matches[1]&embed=true\";s:40:\"project_tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?project_tag=$matches[1]&paged=$matches[2]\";s:22:\"project_tag/([^/]+)/?$\";s:33:\"index.php?project_tag=$matches[1]\";s:56:\"projects/series/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:51:\"projects/series/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:32:\"projects/series/([^/]+)/embed/?$\";s:49:\"index.php?project_category=$matches[1]&embed=true\";s:44:\"projects/series/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?project_category=$matches[1]&paged=$matches[2]\";s:26:\"projects/series/([^/]+)/?$\";s:38:\"index.php?project_category=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:12:\"sitemap\\.xml\";s:23:\"index.php?sitemap=index\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=40&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','on'),
(31,'hack_file','0','on'),
(32,'blog_charset','UTF-8','on'),
(33,'moderation_keys','','off'),
(34,'active_plugins','a:1:{i:0;s:25:\"s3-uploads/s3-uploads.php\";}','on'),
(35,'category_base','','on'),
(36,'ping_sites','https://rpc.pingomatic.com/','on'),
(37,'comment_max_links','2','on'),
(38,'gmt_offset','0','on'),
(39,'default_email_category','1','on'),
(40,'recently_edited','','off'),
(41,'template','demo-theme','on'),
(42,'stylesheet','demo-theme','on'),
(43,'comment_registration','0','on'),
(44,'html_type','text/html','on'),
(45,'use_trackback','0','on'),
(46,'default_role','subscriber','on'),
(47,'db_version','61833','on'),
(48,'uploads_use_yearmonth_folders','1','on'),
(49,'upload_path','','on'),
(50,'blog_public','1','on'),
(51,'default_link_category','2','on'),
(52,'show_on_front','page','on'),
(53,'tag_base','','on'),
(54,'show_avatars','1','on'),
(55,'avatar_rating','G','on'),
(56,'upload_url_path','','on'),
(57,'thumbnail_size_w','150','on'),
(58,'thumbnail_size_h','150','on'),
(59,'thumbnail_crop','1','on'),
(60,'medium_size_w','300','on'),
(61,'medium_size_h','300','on'),
(62,'avatar_default','mystery','on'),
(63,'large_size_w','1024','on'),
(64,'large_size_h','1024','on'),
(65,'image_default_link_type','none','on'),
(66,'image_default_size','','on'),
(67,'image_default_align','','on'),
(68,'close_comments_for_old_posts','0','on'),
(69,'close_comments_days_old','14','on'),
(70,'thread_comments','1','on'),
(71,'thread_comments_depth','5','on'),
(72,'page_comments','0','on'),
(73,'comments_per_page','50','on'),
(74,'default_comments_page','newest','on'),
(75,'comment_order','asc','on'),
(76,'sticky_posts','a:0:{}','on'),
(77,'widget_categories','a:0:{}','on'),
(78,'widget_text','a:0:{}','on'),
(79,'widget_rss','a:0:{}','on'),
(80,'uninstall_plugins','a:0:{}','off'),
(81,'timezone_string','','on'),
(82,'page_for_posts','0','on'),
(83,'page_on_front','40','on'),
(84,'default_post_format','0','on'),
(85,'link_manager_enabled','0','on'),
(86,'finished_splitting_shared_terms','1','on'),
(87,'site_icon','0','on'),
(88,'medium_large_size_w','768','on'),
(89,'medium_large_size_h','0','on'),
(90,'wp_page_for_privacy_policy','3','on'),
(91,'show_comments_cookies_opt_in','1','on'),
(92,'admin_email_lifespan','1802765830','on'),
(93,'disallowed_keys','','off'),
(94,'comment_previously_approved','1','on'),
(95,'auto_plugin_theme_update_emails','a:0:{}','off'),
(96,'auto_update_core_dev','enabled','on'),
(97,'auto_update_core_minor','enabled','on'),
(98,'auto_update_core_major','enabled','on'),
(99,'wp_force_deactivated_plugins','a:0:{}','on'),
(100,'wp_attachment_pages_enabled','0','on'),
(101,'wp_notes_notify','1','on'),
(102,'initial_db_version','61833','on'),
(103,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','on'),
(104,'fresh_site','0','off'),
(105,'user_count','1','off'),
(106,'widget_block','a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}','auto'),
(107,'sidebars_widgets','a:2:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}','auto'),
(108,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(109,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(110,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(111,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(112,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(113,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(114,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(115,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(116,'widget_search','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(117,'widget_recent-posts','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(118,'widget_recent-comments','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(119,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(120,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(121,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(125,'recovery_keys','a:0:{}','off'),
(126,'_site_transient_timeout_theme_roots','1787215632','off'),
(127,'_site_transient_theme_roots','a:1:{s:10:\"demo-theme\";s:7:\"/themes\";}','off'),
(128,'theme_mods_twentytwentyfive','a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1787213832;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}','off'),
(129,'current_theme','Demo Theme','auto'),
(130,'theme_switched','','auto'),
(134,'theme_mods_demo-theme','a:2:{s:18:\"nav_menu_locations\";a:3:{s:6:\"header\";i:7;s:6:\"footer\";i:8;s:5:\"legal\";i:9;}s:18:\"custom_css_post_id\";i:-1;}','auto'),
(139,'project_category_children','a:0:{}','auto'),
(140,'demo_contact_email','studio@foehn.test','auto'),
(142,'_transient_wp_styles_for_blocks','a:2:{s:4:\"hash\";s:32:\"94289267f68ccac1fefa45915ab93347\";s:6:\"blocks\";a:9:{s:32:\"832dc2d864d79097d8b8b493ad93453b\";s:0:\"\";s:32:\"45d3e0c4afcbd8cf25cb1ba51abfb3d7\";s:46:\":root :where(.wp-block-icon svg){width: 24px;}\";s:32:\"feca6e996f694be2d29599793228e0d7\";s:0:\"\";s:32:\"5eef131663eddaf830554df656fc2968\";s:324:\":where(.wp-block-gallery.is-layout-flex){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}:where(.wp-block-gallery.is-layout-grid){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}\";s:32:\"c99c05932c6685777ec5b856698fcc7d\";s:118:\":where(.wp-block-latest-posts.is-layout-flex){gap: 1.25em;}:where(.wp-block-latest-posts.is-layout-grid){gap: 1.25em;}\";s:32:\"dec8d648f30b13caec8e61374591787d\";s:120:\":where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}\";s:32:\"6c35533f7a92cce94808323603db9fc8\";s:120:\":where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}\";s:32:\"6a0505cd5c78a87ed77570cda43c1132\";s:102:\":where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}\";s:32:\"25a66f156386551185570f72a9f7d44e\";s:69:\":root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}\";}}','on'),
(147,'foehn_rewrite_rules_hash','84d5d4d9a7411f58f36cb90c9ec6d072','auto'),
(151,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-7.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-7.1.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-7.1-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-7.1-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"7.1\";s:7:\"version\";s:3:\"7.1\";s:11:\"php_version\";s:3:\"7.4\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1787218307;s:15:\"version_checked\";s:3:\"7.1\";s:12:\"translations\";a:0:{}}','off'),
(153,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1787219717;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:0:{}s:7:\"checked\";a:1:{s:25:\"s3-uploads/s3-uploads.php\";s:6:\"3.0.11\";}}','off'),
(154,'_site_transient_timeout_wp_theme_files_patterns-d30d6f4b8d00c16b2dfbcf5e12be16b9','1787222024','off'),
(155,'_site_transient_wp_theme_files_patterns-d30d6f4b8d00c16b2dfbcf5e12be16b9','a:2:{s:7:\"version\";s:5:\"1.0.0\";s:8:\"patterns\";a:0:{}}','off');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES
(1,2,'_wp_page_template','default'),
(2,3,'_wp_page_template','default'),
(3,4,'_wp_attached_file','2026/08/corridors-01-LCJ9iOli-uE.jpg'),
(4,4,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1068;s:4:\"file\";s:36:\"2026/08/corridors-01-LCJ9iOli-uE.jpg\";s:8:\"filesize\";i:133560;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"corridors-01-LCJ9iOli-uE-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"corridors-01-LCJ9iOli-uE-1024x684.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"corridors-01-LCJ9iOli-uE-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"corridors-01-LCJ9iOli-uE-768x513.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"corridors-01-LCJ9iOli-uE-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:36:\"corridors-01-LCJ9iOli-uE-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(5,4,'unsplash_id','LCJ9iOli-uE'),
(6,4,'credit_photographer','Amanda Marie'),
(7,4,'credit_url','https://unsplash.com/@gdtography'),
(8,4,'credit_source','https://unsplash.com/photos/photo-of-white-painted-building-LCJ9iOli-uE'),
(9,4,'_wp_attachment_image_alt','Modern white corridor'),
(10,5,'_wp_attached_file','2026/08/corridors-02-9cU-HC5CND8.jpg'),
(11,5,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:997;s:6:\"height\";i:1600;s:4:\"file\";s:36:\"2026/08/corridors-02-9cU-HC5CND8.jpg\";s:8:\"filesize\";i:149781;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"corridors-02-9cU-HC5CND8-187x300.jpg\";s:5:\"width\";i:187;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"corridors-02-9cU-HC5CND8-638x1024.jpg\";s:5:\"width\";i:638;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"corridors-02-9cU-HC5CND8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"corridors-02-9cU-HC5CND8-768x1232.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1232;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:37:\"corridors-02-9cU-HC5CND8-957x1536.jpg\";s:5:\"width\";i:957;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:37:\"corridors-02-9cU-HC5CND8-997x1080.jpg\";s:5:\"width\";i:997;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:36:\"corridors-02-9cU-HC5CND8-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(12,5,'unsplash_id','9cU_HC5CND8'),
(13,5,'credit_photographer','Joel Filipe'),
(14,5,'credit_url','https://unsplash.com/@joelfilip'),
(15,5,'credit_source','https://unsplash.com/photos/architectural-photography-of-white-building-9cU_HC5CND8'),
(16,5,'_wp_attachment_image_alt','White ribbed facade'),
(17,6,'_wp_attached_file','2026/08/corridors-03-hxi-yRxODNc.jpg'),
(18,6,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1067;s:6:\"height\";i:1600;s:4:\"file\";s:36:\"2026/08/corridors-03-hxi-yRxODNc.jpg\";s:8:\"filesize\";i:128029;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"corridors-03-hxi-yRxODNc-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"corridors-03-hxi-yRxODNc-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"corridors-03-hxi-yRxODNc-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"corridors-03-hxi-yRxODNc-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"corridors-03-hxi-yRxODNc-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:38:\"corridors-03-hxi-yRxODNc-1067x1080.jpg\";s:5:\"width\";i:1067;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:36:\"corridors-03-hxi-yRxODNc-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(19,6,'unsplash_id','hxi_yRxODNc'),
(20,6,'credit_photographer','bady abbas'),
(21,6,'credit_url','https://unsplash.com/@bady'),
(22,6,'credit_source','https://unsplash.com/photos/white-concrete-building-facade-pattern-hxi_yRxODNc'),
(23,6,'_wp_attachment_image_alt','Window on murray building'),
(24,7,'_wp_attached_file','2026/08/corridors-04-WOSvM6tPHBQ.jpg'),
(25,7,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1143;s:6:\"height\";i:1600;s:4:\"file\";s:36:\"2026/08/corridors-04-WOSvM6tPHBQ.jpg\";s:8:\"filesize\";i:211700;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"corridors-04-WOSvM6tPHBQ-214x300.jpg\";s:5:\"width\";i:214;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"corridors-04-WOSvM6tPHBQ-732x1024.jpg\";s:5:\"width\";i:732;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"corridors-04-WOSvM6tPHBQ-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"corridors-04-WOSvM6tPHBQ-768x1075.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1075;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"corridors-04-WOSvM6tPHBQ-1097x1536.jpg\";s:5:\"width\";i:1097;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:38:\"corridors-04-WOSvM6tPHBQ-1143x1080.jpg\";s:5:\"width\";i:1143;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:36:\"corridors-04-WOSvM6tPHBQ-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(26,7,'unsplash_id','WOSvM6tPHBQ'),
(27,7,'credit_photographer','Alex Rodríguez Santibáñez'),
(28,7,'credit_url','https://unsplash.com/@alexrds'),
(29,7,'credit_source','https://unsplash.com/photos/white-and-black-wall-WOSvM6tPHBQ'),
(30,7,'_wp_attachment_image_alt','window on white wall mexico'),
(31,8,'_wp_attached_file','2026/08/corridors-05-zw07kVDaHPw.jpg'),
(32,8,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1068;s:4:\"file\";s:36:\"2026/08/corridors-05-zw07kVDaHPw.jpg\";s:8:\"filesize\";i:62484;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"corridors-05-zw07kVDaHPw-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"corridors-05-zw07kVDaHPw-1024x684.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"corridors-05-zw07kVDaHPw-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"corridors-05-zw07kVDaHPw-768x513.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"corridors-05-zw07kVDaHPw-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:36:\"corridors-05-zw07kVDaHPw-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(33,8,'unsplash_id','zw07kVDaHPw'),
(34,8,'credit_photographer','Alexander Andrews'),
(35,8,'credit_url','https://unsplash.com/@alex_andrews'),
(36,8,'credit_source','https://unsplash.com/photos/a-decorative-lettering-zw07kVDaHPw'),
(37,8,'_wp_attachment_image_alt','A decorative lettering'),
(38,9,'_wp_attached_file','2026/08/silhouettes-01-kX9lb7LUDWc-1.jpg'),
(39,9,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:40:\"2026/08/silhouettes-01-kX9lb7LUDWc-1.jpg\";s:8:\"filesize\";i:44997;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"silhouettes-01-kX9lb7LUDWc-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"silhouettes-01-kX9lb7LUDWc-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"silhouettes-01-kX9lb7LUDWc-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"silhouettes-01-kX9lb7LUDWc-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:42:\"silhouettes-01-kX9lb7LUDWc-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:40:\"silhouettes-01-kX9lb7LUDWc-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(40,9,'unsplash_id','kX9lb7LUDWc'),
(41,9,'credit_photographer','Matthew Henry'),
(42,9,'credit_url','https://unsplash.com/@matthewhenry'),
(43,9,'credit_source','https://unsplash.com/photos/grayscale-photogaphy-of-man-sitting-on-concrete-bench-kX9lb7LUDWc'),
(44,9,'_wp_attachment_image_alt','grayscale photogaphy of man sitting on concrete bench'),
(45,10,'_wp_attached_file','2026/08/silhouettes-02-x-Brii2QaM-1.jpg'),
(46,10,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:860;s:4:\"file\";s:39:\"2026/08/silhouettes-02-x-Brii2QaM-1.jpg\";s:8:\"filesize\";i:65544;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"silhouettes-02-x-Brii2QaM-1-300x161.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:161;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"silhouettes-02-x-Brii2QaM-1-1024x550.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"silhouettes-02-x-Brii2QaM-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"silhouettes-02-x-Brii2QaM-1-768x413.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:413;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:40:\"silhouettes-02-x-Brii2QaM-1-1536x826.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:826;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:39:\"silhouettes-02-x-Brii2QaM-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(47,10,'unsplash_id','-x-Brii2QaM'),
(48,10,'credit_photographer','Vasily Koloda'),
(49,10,'credit_url','https://unsplash.com/@napr0tiv'),
(50,10,'credit_source','https://unsplash.com/photos/man-walking-on-white-surface--x-Brii2QaM'),
(51,10,'_wp_attachment_image_alt','man walking on white surface'),
(52,11,'_wp_attached_file','2026/08/silhouettes-03-ZNVGL-Pcf74-1.jpg'),
(53,11,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1375;s:6:\"height\";i:1600;s:4:\"file\";s:40:\"2026/08/silhouettes-03-ZNVGL-Pcf74-1.jpg\";s:8:\"filesize\";i:109105;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"silhouettes-03-ZNVGL-Pcf74-1-258x300.jpg\";s:5:\"width\";i:258;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"silhouettes-03-ZNVGL-Pcf74-1-880x1024.jpg\";s:5:\"width\";i:880;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"silhouettes-03-ZNVGL-Pcf74-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"silhouettes-03-ZNVGL-Pcf74-1-768x894.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:894;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:42:\"silhouettes-03-ZNVGL-Pcf74-1-1320x1536.jpg\";s:5:\"width\";i:1320;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:42:\"silhouettes-03-ZNVGL-Pcf74-1-1375x1080.jpg\";s:5:\"width\";i:1375;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:40:\"silhouettes-03-ZNVGL-Pcf74-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(54,11,'unsplash_id','ZNVGL_Pcf74'),
(55,11,'credit_photographer','🇸🇮 Janko Ferlič'),
(56,11,'credit_url','https://unsplash.com/@itfeelslikefilm'),
(57,11,'credit_source','https://unsplash.com/photos/pregnant-woman-in-silhouette-ZNVGL_Pcf74'),
(58,11,'_wp_attachment_image_alt','A pregnant woman in silhouette holding her belly against a bright white background'),
(59,12,'_wp_attached_file','2026/08/silhouettes-04-R9OueKOtGGU-1.jpg'),
(60,12,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1067;s:6:\"height\";i:1600;s:4:\"file\";s:40:\"2026/08/silhouettes-04-R9OueKOtGGU-1.jpg\";s:8:\"filesize\";i:50592;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"silhouettes-04-R9OueKOtGGU-1-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"silhouettes-04-R9OueKOtGGU-1-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"silhouettes-04-R9OueKOtGGU-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"silhouettes-04-R9OueKOtGGU-1-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:42:\"silhouettes-04-R9OueKOtGGU-1-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:42:\"silhouettes-04-R9OueKOtGGU-1-1067x1080.jpg\";s:5:\"width\";i:1067;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:40:\"silhouettes-04-R9OueKOtGGU-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(61,12,'unsplash_id','R9OueKOtGGU'),
(62,12,'credit_photographer','ÉMILE SÉGUIN 🧩🧩🧩'),
(63,12,'credit_url','https://unsplash.com/@emileseguin'),
(64,12,'credit_source','https://unsplash.com/photos/person-walking-on-snowfield-R9OueKOtGGU'),
(65,12,'_wp_attachment_image_alt','Déjà Vu'),
(66,13,'_wp_attached_file','2026/08/winter-01-Du41jIaI5Ww.jpg'),
(67,13,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:33:\"2026/08/winter-01-Du41jIaI5Ww.jpg\";s:8:\"filesize\";i:96258;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"winter-01-Du41jIaI5Ww-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"winter-01-Du41jIaI5Ww-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"winter-01-Du41jIaI5Ww-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"winter-01-Du41jIaI5Ww-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"winter-01-Du41jIaI5Ww-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:33:\"winter-01-Du41jIaI5Ww-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(68,13,'unsplash_id','Du41jIaI5Ww'),
(69,13,'credit_photographer','Fabrice Villard'),
(70,13,'credit_url','https://unsplash.com/@fabulu75'),
(71,13,'credit_source','https://unsplash.com/photos/withered-tree-surrounded-with-snow-during-daytime-Du41jIaI5Ww'),
(72,13,'_wp_attachment_image_alt','withered tree surrounded with snow during daytime'),
(73,14,'_wp_attached_file','2026/08/winter-02-4L-AyDJM-yM.jpg'),
(74,14,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:33:\"2026/08/winter-02-4L-AyDJM-yM.jpg\";s:8:\"filesize\";i:58416;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"winter-02-4L-AyDJM-yM-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"winter-02-4L-AyDJM-yM-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"winter-02-4L-AyDJM-yM-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"winter-02-4L-AyDJM-yM-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"winter-02-4L-AyDJM-yM-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:33:\"winter-02-4L-AyDJM-yM-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(75,14,'unsplash_id','4L-AyDJM-yM'),
(76,14,'credit_photographer','Cristina Gottardi'),
(77,14,'credit_url','https://unsplash.com/@cristina_gottardi'),
(78,14,'credit_source','https://unsplash.com/photos/pine-tree-covered-with-snow-4L-AyDJM-yM'),
(79,14,'_wp_attachment_image_alt','pine tree covered with snow'),
(80,15,'_wp_attached_file','2026/08/winter-03-kLwAv4D8eCs.jpg'),
(81,15,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1068;s:6:\"height\";i:1600;s:4:\"file\";s:33:\"2026/08/winter-03-kLwAv4D8eCs.jpg\";s:8:\"filesize\";i:283967;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"winter-03-kLwAv4D8eCs-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"winter-03-kLwAv4D8eCs-684x1024.jpg\";s:5:\"width\";i:684;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"winter-03-kLwAv4D8eCs-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"winter-03-kLwAv4D8eCs-768x1151.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1151;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"winter-03-kLwAv4D8eCs-1025x1536.jpg\";s:5:\"width\";i:1025;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:35:\"winter-03-kLwAv4D8eCs-1068x1080.jpg\";s:5:\"width\";i:1068;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:33:\"winter-03-kLwAv4D8eCs-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(82,15,'unsplash_id','kLwAv4D8eCs'),
(83,15,'credit_photographer','takaharu SAWA'),
(84,15,'credit_url','https://unsplash.com/@haru88'),
(85,15,'credit_source','https://unsplash.com/photos/kLwAv4D8eCs'),
(86,15,'_wp_attachment_image_alt','Telephone pole'),
(87,16,'_wp_attached_file','2026/08/winter-04-UXLD2XHnWds.jpg'),
(88,16,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1067;s:6:\"height\";i:1600;s:4:\"file\";s:33:\"2026/08/winter-04-UXLD2XHnWds.jpg\";s:8:\"filesize\";i:277596;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"winter-04-UXLD2XHnWds-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"winter-04-UXLD2XHnWds-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"winter-04-UXLD2XHnWds-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"winter-04-UXLD2XHnWds-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"winter-04-UXLD2XHnWds-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:35:\"winter-04-UXLD2XHnWds-1067x1080.jpg\";s:5:\"width\";i:1067;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:33:\"winter-04-UXLD2XHnWds-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(89,16,'unsplash_id','UXLD2XHnWds'),
(90,16,'credit_photographer','takaharu SAWA'),
(91,16,'credit_url','https://unsplash.com/@haru88'),
(92,16,'credit_source','https://unsplash.com/photos/low-angle-photography-of-high-rise-building-UXLD2XHnWds'),
(93,16,'_wp_attachment_image_alt','no Title'),
(94,17,'_wp_attached_file','2026/08/objects-01-VBPzRgd7gfc.jpg'),
(95,17,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:34:\"2026/08/objects-01-VBPzRgd7gfc.jpg\";s:8:\"filesize\";i:133395;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"objects-01-VBPzRgd7gfc-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"objects-01-VBPzRgd7gfc-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"objects-01-VBPzRgd7gfc-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"objects-01-VBPzRgd7gfc-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"objects-01-VBPzRgd7gfc-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"objects-01-VBPzRgd7gfc-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(96,17,'unsplash_id','VBPzRgd7gfc'),
(97,17,'credit_photographer','Kelly Sikkema'),
(98,17,'credit_url','https://unsplash.com/@kellysikkema'),
(99,17,'credit_source','https://unsplash.com/photos/graphing-notebook-VBPzRgd7gfc'),
(100,17,'_wp_attachment_image_alt','Grid notebook and Muji pen'),
(101,18,'_wp_attached_file','2026/08/objects-02-NuOGFo4PudE.jpg'),
(102,18,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2026/08/objects-02-NuOGFo4PudE.jpg\";s:8:\"filesize\";i:33334;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"objects-02-NuOGFo4PudE-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"objects-02-NuOGFo4PudE-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"objects-02-NuOGFo4PudE-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"objects-02-NuOGFo4PudE-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"objects-02-NuOGFo4PudE-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:36:\"objects-02-NuOGFo4PudE-1200x1080.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"objects-02-NuOGFo4PudE-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(103,18,'unsplash_id','NuOGFo4PudE'),
(104,18,'credit_photographer','Kuiye Chen'),
(105,18,'credit_url','https://unsplash.com/@kuiye'),
(106,18,'credit_source','https://unsplash.com/photos/apple-airpods-NuOGFo4PudE'),
(107,18,'_wp_attachment_image_alt','AirPods'),
(108,19,'_wp_attached_file','2026/08/objects-03-vpOJwXxxpJ4.jpg'),
(109,19,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2026/08/objects-03-vpOJwXxxpJ4.jpg\";s:8:\"filesize\";i:64269;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"objects-03-vpOJwXxxpJ4-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"objects-03-vpOJwXxxpJ4-819x1024.jpg\";s:5:\"width\";i:819;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"objects-03-vpOJwXxxpJ4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"objects-03-vpOJwXxxpJ4-768x960.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"objects-03-vpOJwXxxpJ4-1229x1536.jpg\";s:5:\"width\";i:1229;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:36:\"objects-03-vpOJwXxxpJ4-1280x1080.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"objects-03-vpOJwXxxpJ4-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(110,19,'unsplash_id','vpOJwXxxpJ4'),
(111,19,'credit_photographer','Leander Lenzing'),
(112,19,'credit_url','https://unsplash.com/@leanderlenzing'),
(113,19,'credit_source','https://unsplash.com/photos/white-metal-armchair-with-white-background-vpOJwXxxpJ4'),
(114,19,'_wp_attachment_image_alt','Pants on chair'),
(115,20,'_wp_attached_file','2026/08/objects-04-sDeGlMAwcH4.jpg'),
(116,20,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:34:\"2026/08/objects-04-sDeGlMAwcH4.jpg\";s:8:\"filesize\";i:60977;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"objects-04-sDeGlMAwcH4-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"objects-04-sDeGlMAwcH4-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"objects-04-sDeGlMAwcH4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"objects-04-sDeGlMAwcH4-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"objects-04-sDeGlMAwcH4-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"objects-04-sDeGlMAwcH4-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(117,20,'unsplash_id','sDeGlMAwcH4'),
(118,20,'credit_photographer','Jagoda Kondratiuk'),
(119,20,'credit_url','https://unsplash.com/@jagodakondratiuk'),
(120,20,'credit_source','https://unsplash.com/photos/sugar-block-dropped-on-white-cup-with-milk-sDeGlMAwcH4'),
(121,20,'_wp_attachment_image_alt','sugar block dropped on white cup with milk'),
(122,21,'_wp_attached_file','2026/08/objects-05-34lqQKELTT4.jpg'),
(123,21,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1067;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2026/08/objects-05-34lqQKELTT4.jpg\";s:8:\"filesize\";i:92834;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"objects-05-34lqQKELTT4-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"objects-05-34lqQKELTT4-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"objects-05-34lqQKELTT4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"objects-05-34lqQKELTT4-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"objects-05-34lqQKELTT4-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:36:\"objects-05-34lqQKELTT4-1067x1080.jpg\";s:5:\"width\";i:1067;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"objects-05-34lqQKELTT4-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(124,21,'unsplash_id','34lqQKELTT4'),
(125,21,'credit_photographer','Alev Takil'),
(126,21,'credit_url','https://unsplash.com/@alevtakil'),
(127,21,'credit_source','https://unsplash.com/photos/person-holding-fencing-sword-34lqQKELTT4'),
(128,21,'_wp_attachment_image_alt','A fencer\'s sword, close up'),
(129,22,'_wp_attached_file','2026/08/osaka-01-v2aoMh8xf0-1.jpg'),
(130,22,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1071;s:4:\"file\";s:33:\"2026/08/osaka-01-v2aoMh8xf0-1.jpg\";s:8:\"filesize\";i:231307;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"osaka-01-v2aoMh8xf0-1-300x201.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"osaka-01-v2aoMh8xf0-1-1024x685.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"osaka-01-v2aoMh8xf0-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"osaka-01-v2aoMh8xf0-1-768x514.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"osaka-01-v2aoMh8xf0-1-1536x1028.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:33:\"osaka-01-v2aoMh8xf0-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(131,22,'unsplash_id','_v2aoMh8xf0'),
(132,22,'credit_photographer','Daryan Shamkhali'),
(133,22,'credit_url','https://unsplash.com/@daryan'),
(134,22,'credit_source','https://unsplash.com/photos/white-and-black-striped-illustration-_v2aoMh8xf0'),
(135,22,'_wp_attachment_image_alt','monochrome floor osaka'),
(136,23,'_wp_attached_file','2026/08/osaka-02-fTvlM-68oZM-1.jpg'),
(137,23,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1042;s:4:\"file\";s:34:\"2026/08/osaka-02-fTvlM-68oZM-1.jpg\";s:8:\"filesize\";i:90003;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"osaka-02-fTvlM-68oZM-1-300x195.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:195;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"osaka-02-fTvlM-68oZM-1-1024x667.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:667;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"osaka-02-fTvlM-68oZM-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"osaka-02-fTvlM-68oZM-1-768x500.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"osaka-02-fTvlM-68oZM-1-1536x1000.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1000;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"osaka-02-fTvlM-68oZM-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(138,23,'unsplash_id','fTvlM_68oZM'),
(139,23,'credit_photographer','Viktor Forgacs'),
(140,23,'credit_url','https://unsplash.com/@sonance'),
(141,23,'credit_source','https://unsplash.com/photos/gray-concrete-building-during-daytime-fTvlM_68oZM'),
(142,23,'_wp_attachment_image_alt','If you would like to support my work, visit https://www.paypal.me/viktorforgacs (20% goes to charities)'),
(143,24,'_wp_attached_file','2026/08/osaka-03-NECyhRpxGmU-1.jpg'),
(144,24,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1069;s:4:\"file\";s:34:\"2026/08/osaka-03-NECyhRpxGmU-1.jpg\";s:8:\"filesize\";i:280558;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"osaka-03-NECyhRpxGmU-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"osaka-03-NECyhRpxGmU-1-1024x684.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"osaka-03-NECyhRpxGmU-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"osaka-03-NECyhRpxGmU-1-768x513.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"osaka-03-NECyhRpxGmU-1-1536x1026.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1026;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"osaka-03-NECyhRpxGmU-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(145,24,'unsplash_id','NECyhRpxGmU'),
(146,24,'credit_photographer','Viktor Forgacs'),
(147,24,'credit_url','https://unsplash.com/@sonance'),
(148,24,'credit_source','https://unsplash.com/photos/gray-high-rise-building-NECyhRpxGmU'),
(149,24,'_wp_attachment_image_alt','If you would like to support my work, visit https://www.paypal.me/viktorforgacs (20% goes to charities)'),
(150,25,'_wp_attached_file','2026/08/osaka-04-jZJn74JUwSE-1.jpg'),
(151,25,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1236;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2026/08/osaka-04-jZJn74JUwSE-1.jpg\";s:8:\"filesize\";i:182562;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"osaka-04-jZJn74JUwSE-1-232x300.jpg\";s:5:\"width\";i:232;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"osaka-04-jZJn74JUwSE-1-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"osaka-04-jZJn74JUwSE-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"osaka-04-jZJn74JUwSE-1-768x994.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:994;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"osaka-04-jZJn74JUwSE-1-1187x1536.jpg\";s:5:\"width\";i:1187;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:36:\"osaka-04-jZJn74JUwSE-1-1236x1080.jpg\";s:5:\"width\";i:1236;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"osaka-04-jZJn74JUwSE-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(152,25,'unsplash_id','jZJn74JUwSE'),
(153,25,'credit_photographer','Viktor Forgacs'),
(154,25,'credit_url','https://unsplash.com/@sonance'),
(155,25,'credit_source','https://unsplash.com/photos/jZJn74JUwSE'),
(156,25,'_wp_attachment_image_alt','Viktor Forgacs'),
(157,26,'_wp_attached_file','2026/08/osaka-05-tFu9EMyR87E-1.jpg'),
(158,26,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1067;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2026/08/osaka-05-tFu9EMyR87E-1.jpg\";s:8:\"filesize\";i:97077;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"osaka-05-tFu9EMyR87E-1-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"osaka-05-tFu9EMyR87E-1-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"osaka-05-tFu9EMyR87E-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"osaka-05-tFu9EMyR87E-1-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"osaka-05-tFu9EMyR87E-1-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:36:\"osaka-05-tFu9EMyR87E-1-1067x1080.jpg\";s:5:\"width\";i:1067;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:34:\"osaka-05-tFu9EMyR87E-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(159,26,'unsplash_id','tFu9EMyR87E'),
(160,26,'credit_photographer','Ciocan Ciprian'),
(161,26,'credit_url','https://unsplash.com/@cipriann'),
(162,26,'credit_source','https://unsplash.com/photos/statue-of-liberty-tFu9EMyR87E'),
(163,26,'_wp_attachment_image_alt','Statue of Liberty'),
(164,27,'_wp_attached_file','2026/08/editions-01-RWRnUMWtOWk-1.jpg'),
(165,27,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:37:\"2026/08/editions-01-RWRnUMWtOWk-1.jpg\";s:8:\"filesize\";i:93575;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"editions-01-RWRnUMWtOWk-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"editions-01-RWRnUMWtOWk-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"editions-01-RWRnUMWtOWk-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"editions-01-RWRnUMWtOWk-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:39:\"editions-01-RWRnUMWtOWk-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:37:\"editions-01-RWRnUMWtOWk-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(166,27,'unsplash_id','RWRnUMWtOWk'),
(167,27,'credit_photographer','Water Journal'),
(168,27,'credit_url','https://unsplash.com/@waterjournal'),
(169,27,'credit_source','https://unsplash.com/photos/RWRnUMWtOWk'),
(170,27,'_wp_attachment_image_alt','Water Journal is a bi-annual publication exploring the beauty and complexity of all things water. Dedicated to the experience and cultural significance of water, it exists to tell honest stories, whether it’s of a personal matter or on a global scale. Featured essay: Kristina Chelberg'),
(171,28,'_wp_attached_file','2026/08/editions-02-EbuaKnSm8Zw-1.jpg'),
(172,28,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1068;s:4:\"file\";s:37:\"2026/08/editions-02-EbuaKnSm8Zw-1.jpg\";s:8:\"filesize\";i:65017;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"editions-02-EbuaKnSm8Zw-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"editions-02-EbuaKnSm8Zw-1-1024x684.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"editions-02-EbuaKnSm8Zw-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"editions-02-EbuaKnSm8Zw-1-768x513.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:39:\"editions-02-EbuaKnSm8Zw-1-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:37:\"editions-02-EbuaKnSm8Zw-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(173,28,'unsplash_id','EbuaKnSm8Zw'),
(174,28,'credit_photographer','Water Journal'),
(175,28,'credit_url','https://unsplash.com/@waterjournal'),
(176,28,'credit_source','https://unsplash.com/photos/book-on-top-of-white-surface-EbuaKnSm8Zw'),
(177,28,'_wp_attachment_image_alt','Water Journal is a bi-annual publication exploring the beauty and complexity of all things water. Dedicated to the experience and cultural significance of water, it exists to tell honest stories, whether it’s of a personal matter or on a global scale. Cover photography: Troy Moth'),
(178,29,'_wp_attached_file','2026/08/editions-03-HY3l4IeOc3E-1.jpg'),
(179,29,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1000;s:4:\"file\";s:37:\"2026/08/editions-03-HY3l4IeOc3E-1.jpg\";s:8:\"filesize\";i:59005;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"editions-03-HY3l4IeOc3E-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"editions-03-HY3l4IeOc3E-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"editions-03-HY3l4IeOc3E-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"editions-03-HY3l4IeOc3E-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"editions-03-HY3l4IeOc3E-1-1536x960.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:37:\"editions-03-HY3l4IeOc3E-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(180,29,'unsplash_id','HY3l4IeOc3E'),
(181,29,'credit_photographer','Julian O\'hayon'),
(182,29,'credit_url','https://unsplash.com/@anckor'),
(183,29,'credit_source','https://unsplash.com/photos/black-macbook-near-black-iphone-7-plus-and-black-apple-watch-HY3l4IeOc3E'),
(184,29,'_wp_attachment_image_alt','Wallpapers “Black Serie” from anckor.com'),
(185,30,'_wp_attached_file','2026/08/editions-04-YIPSx8PFi9s-1.jpg'),
(186,30,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1063;s:6:\"height\";i:1600;s:4:\"file\";s:37:\"2026/08/editions-04-YIPSx8PFi9s-1.jpg\";s:8:\"filesize\";i:88020;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"editions-04-YIPSx8PFi9s-1-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"editions-04-YIPSx8PFi9s-1-680x1024.jpg\";s:5:\"width\";i:680;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"editions-04-YIPSx8PFi9s-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"editions-04-YIPSx8PFi9s-1-768x1156.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1156;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:39:\"editions-04-YIPSx8PFi9s-1-1020x1536.jpg\";s:5:\"width\";i:1020;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:39:\"editions-04-YIPSx8PFi9s-1-1063x1080.jpg\";s:5:\"width\";i:1063;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:37:\"editions-04-YIPSx8PFi9s-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(187,30,'unsplash_id','YIPSx8PFi9s'),
(188,30,'credit_photographer','yapo zhou'),
(189,30,'credit_url','https://unsplash.com/@nic1986'),
(190,30,'credit_source','https://unsplash.com/photos/a-black-and-white-photo-of-a-bunch-of-flowers-YIPSx8PFi9s'),
(191,30,'_wp_attachment_image_alt','a black and white photo of a bunch of flowers'),
(192,31,'_wp_attached_file','2026/08/editions-05-MAgPyHRO0AA-1.jpg'),
(193,31,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1071;s:4:\"file\";s:37:\"2026/08/editions-05-MAgPyHRO0AA-1.jpg\";s:8:\"filesize\";i:153060;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"editions-05-MAgPyHRO0AA-1-300x201.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"editions-05-MAgPyHRO0AA-1-1024x685.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"editions-05-MAgPyHRO0AA-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"editions-05-MAgPyHRO0AA-1-768x514.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:39:\"editions-05-MAgPyHRO0AA-1-1536x1028.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:37:\"editions-05-MAgPyHRO0AA-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(194,31,'unsplash_id','MAgPyHRO0AA'),
(195,31,'credit_photographer','Nik'),
(196,31,'credit_url','https://unsplash.com/@helloimnik'),
(197,31,'credit_source','https://unsplash.com/photos/right-arrow-sign-on-wall-MAgPyHRO0AA'),
(198,31,'_wp_attachment_image_alt','If you like my work and you\'d like to support me, you can also consider a donation > http://www.paypal.me/helloimnik. Thank you 😌\n\nThere’s a derelict factory grounds very close to me, this wall has been erected since the car park was closed to stop cars entering. I love the engraved arrow, rather than the usual, obvious plastic signage. I’m always looking for direction, this photo reminds me that every way is a way.'),
(199,32,'_wp_attached_file','2026/08/studio-01-VBWWscZtszY-1.jpg'),
(200,32,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1600;s:4:\"file\";s:35:\"2026/08/studio-01-VBWWscZtszY-1.jpg\";s:8:\"filesize\";i:232085;s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"studio-01-VBWWscZtszY-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"studio-01-VBWWscZtszY-1-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"studio-01-VBWWscZtszY-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"studio-01-VBWWscZtszY-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:37:\"studio-01-VBWWscZtszY-1-1536x1536.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"hero\";a:4:{s:4:\"file\";s:37:\"studio-01-VBWWscZtszY-1-1600x1080.jpg\";s:5:\"width\";i:1600;s:6:\"height\";i:1080;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:35:\"studio-01-VBWWscZtszY-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(201,32,'unsplash_id','VBWWscZtszY'),
(202,32,'credit_photographer','Nicholas Kwok'),
(203,32,'credit_url','https://unsplash.com/@npkwok98'),
(204,32,'credit_source','https://unsplash.com/photos/silhouette-photo-of-a-person-standing-near-wall-in-dark-room-VBWWscZtszY'),
(205,32,'_wp_attachment_image_alt','greed.'),
(206,33,'_wp_attached_file','2026/08/studio-02-cmt3JdS5MC4-1.jpg'),
(207,33,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1600;s:6:\"height\";i:1067;s:4:\"file\";s:35:\"2026/08/studio-02-cmt3JdS5MC4-1.jpg\";s:8:\"filesize\";i:142675;s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"studio-02-cmt3JdS5MC4-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"studio-02-cmt3JdS5MC4-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"studio-02-cmt3JdS5MC4-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"studio-02-cmt3JdS5MC4-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:37:\"studio-02-cmt3JdS5MC4-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:35:\"studio-02-cmt3JdS5MC4-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(208,33,'unsplash_id','cmt3JdS5MC4'),
(209,33,'credit_photographer','Jeremy Bishop'),
(210,33,'credit_url','https://unsplash.com/@jeremybishop'),
(211,33,'credit_source','https://unsplash.com/photos/grayscale-photo-of-man-riding-a-surfboard-cmt3JdS5MC4'),
(212,33,'_wp_attachment_image_alt','Captured in Morro Bay cruisin single stag'),
(213,34,'client','Self-initiated'),
(214,34,'year','2024'),
(215,34,'location','Strasbourg, Basel'),
(216,34,'camera','Hasselblad 500C/M — Ilford HP5+'),
(217,34,'gallery','a:5:{i:0;i:4;i:1;i:5;i:2;i:6;i:3;i:7;i:4;i:8;}'),
(218,34,'_thumbnail_id','4'),
(219,35,'client','Contrejour Review'),
(220,35,'year','2023'),
(221,35,'location','Studio, Strasbourg'),
(222,35,'camera','Nikon FM2 — Kodak Tri-X 400'),
(223,35,'gallery','a:4:{i:0;i:9;i:1;i:10;i:2;i:11;i:3;i:12;}'),
(224,35,'_thumbnail_id','9'),
(225,36,'client','Self-initiated'),
(226,36,'year','2022'),
(227,36,'location','Vosges'),
(228,36,'camera','Mamiya 7 — Fuji Acros 100'),
(229,36,'gallery','a:4:{i:0;i:13;i:1;i:14;i:2;i:15;i:3;i:16;}'),
(230,36,'_thumbnail_id','13'),
(231,37,'client','Grille Editions'),
(232,37,'year','2024'),
(233,37,'location','Studio, Strasbourg'),
(234,37,'camera','Digital — 100 mm macro'),
(235,37,'gallery','a:5:{i:0;i:17;i:1;i:18;i:2;i:19;i:3;i:20;i:4;i:21;}'),
(236,37,'_thumbnail_id','17'),
(237,38,'client','Self-initiated'),
(238,38,'year','2023'),
(239,38,'location','Osaka, Japan'),
(240,38,'camera','Leica M6 — Kodak Tri-X 400'),
(241,38,'gallery','a:5:{i:0;i:22;i:1;i:23;i:2;i:24;i:3;i:25;i:4;i:26;}'),
(242,38,'_thumbnail_id','22'),
(243,39,'client','Water Journal, Grille Editions'),
(244,39,'year','2025'),
(245,39,'location','Studio, Strasbourg'),
(246,39,'camera','Digital — copy stand'),
(247,39,'gallery','a:5:{i:0;i:27;i:1;i:28;i:2;i:29;i:3;i:30;i:4;i:31;}'),
(248,39,'_thumbnail_id','27'),
(249,41,'_thumbnail_id','32'),
(250,42,'author_name','Water Journal'),
(251,42,'author_role','Art direction'),
(252,43,'author_name','Grille Editions'),
(253,43,'author_role','Publishing'),
(254,44,'author_name','Contrejour Review'),
(255,44,'author_role','Editor in chief'),
(296,50,'_wp_attached_file','2026/08/uploads-probe.jpg'),
(297,50,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2026/08/uploads-probe.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"uploads-probe-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"uploads-probe-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"uploads-probe-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"uploads-probe-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:25:\"uploads-probe-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(298,51,'_wp_attached_file','2026/08/uploads-probe.jpg'),
(299,51,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2026/08/uploads-probe.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"uploads-probe-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"uploads-probe-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"uploads-probe-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"uploads-probe-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:25:\"uploads-probe-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(300,52,'_wp_attached_file','2026/08/uploads-probe-1.jpg'),
(301,52,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-1.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(302,53,'_wp_attached_file','2026/08/uploads-probe-2.jpg'),
(303,53,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-2.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(304,54,'_wp_attached_file','2026/08/uploads-probe.jpg'),
(305,54,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2026/08/uploads-probe.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"uploads-probe-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"uploads-probe-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"uploads-probe-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"uploads-probe-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:25:\"uploads-probe-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(306,55,'_wp_attached_file','2026/08/uploads-probe-1.jpg'),
(307,55,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-1.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(308,56,'_wp_attached_file','2026/08/uploads-probe-3.jpg'),
(309,56,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-3.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-3-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-3-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-3-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-3-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(310,57,'_wp_attached_file','2026/08/uploads-probe-4.jpg'),
(311,57,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-4.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-4-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-4-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-4-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-4-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(312,58,'_wp_attached_file','2026/08/uploads-probe-5.jpg'),
(313,58,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-5.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-5-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-5-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-5-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-5-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(314,59,'_wp_attached_file','2026/08/uploads-probe-6.jpg'),
(315,59,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-6.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-6-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-6-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-6-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-6-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(316,41,'faq','a:4:{i:0;a:2:{s:5:\"title\";s:28:\"What does a commission cost?\";s:7:\"content\";s:232:\"A day rate for architecture and editorial work, a per-image rate for still life and reproduction. Both include a first selection and one round of edits; usage rights are quoted separately because they depend on where the images run.\";}i:1;a:2:{s:5:\"title\";s:23:\"Do you shoot in colour?\";s:7:\"content\";s:181:\"Yes, when the brief asks for it. The personal work is black and white because removing colour removes a variable, not because colour is worse — a commission that needs it gets it.\";}i:2;a:2:{s:5:\"title\";s:32:\"How long until I see the images?\";s:7:\"content\";s:197:\"A contact sheet within a week of the shoot, final files two weeks after selection. Film adds a few days for processing, which is worth saying out loud before a deadline is agreed rather than after.\";}i:3;a:2:{s:5:\"title\";s:21:\"Are prints available?\";s:7:\"content\";s:113:\"From any series, in numbered editions of fifteen, printed on baryta paper at 40x50 cm. Larger formats on request.\";}}'),
(317,68,'_menu_item_type','custom'),
(318,68,'_menu_item_menu_item_parent','0'),
(319,68,'_menu_item_object_id','68'),
(320,68,'_menu_item_object','custom'),
(321,68,'_menu_item_target',''),
(322,68,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(323,68,'_menu_item_xfn',''),
(324,68,'_menu_item_url','/projects/'),
(325,69,'_menu_item_type','custom'),
(326,69,'_menu_item_menu_item_parent','0'),
(327,69,'_menu_item_object_id','69'),
(328,69,'_menu_item_object','custom'),
(329,69,'_menu_item_target',''),
(330,69,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(331,69,'_menu_item_xfn',''),
(332,69,'_menu_item_url','https://foehn-demo.ddev.site/about/'),
(333,70,'_menu_item_type','custom'),
(334,70,'_menu_item_menu_item_parent','0'),
(335,70,'_menu_item_object_id','70'),
(336,70,'_menu_item_object','custom'),
(337,70,'_menu_item_target',''),
(338,70,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(339,70,'_menu_item_xfn',''),
(340,70,'_menu_item_url','/projects/'),
(341,71,'_menu_item_type','custom'),
(342,71,'_menu_item_menu_item_parent','0'),
(343,71,'_menu_item_object_id','71'),
(344,71,'_menu_item_object','custom'),
(345,71,'_menu_item_target',''),
(346,71,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(347,71,'_menu_item_xfn',''),
(348,71,'_menu_item_url','https://foehn-demo.ddev.site/about/'),
(349,72,'_menu_item_type','custom'),
(350,72,'_menu_item_menu_item_parent','0'),
(351,72,'_menu_item_object_id','72'),
(352,72,'_menu_item_object','custom'),
(353,72,'_menu_item_target',''),
(354,72,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(355,72,'_menu_item_xfn',''),
(356,72,'_menu_item_url','/legal/'),
(357,73,'_wp_attached_file','2026/08/uploads-probe-7.jpg'),
(358,73,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-7.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-7-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-7-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-7-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-7-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(359,74,'_wp_attached_file','2026/08/uploads-probe-8.jpg'),
(360,74,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-8.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-8-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-8-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-8-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-8-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(361,75,'_wp_attached_file','2026/08/uploads-probe-9.jpg'),
(362,75,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:27:\"2026/08/uploads-probe-9.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"uploads-probe-9-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-9-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"uploads-probe-9-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"uploads-probe-9-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:27:\"uploads-probe-9-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(363,76,'_wp_attached_file','2026/08/uploads-probe-10.jpg'),
(364,76,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2026/08/uploads-probe-10.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"uploads-probe-10-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"uploads-probe-10-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"uploads-probe-10-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-10-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:28:\"uploads-probe-10-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(365,77,'_wp_attached_file','2026/08/uploads-probe-11.jpg'),
(366,77,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2026/08/uploads-probe-11.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"uploads-probe-11-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"uploads-probe-11-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"uploads-probe-11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-11-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:28:\"uploads-probe-11-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(367,78,'_wp_attached_file','2026/08/uploads-probe-12.jpg'),
(368,78,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2026/08/uploads-probe-12.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"uploads-probe-12-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"uploads-probe-12-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"uploads-probe-12-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-12-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:28:\"uploads-probe-12-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(369,79,'_wp_attached_file','2026/08/uploads-probe-13.jpg'),
(370,79,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2026/08/uploads-probe-13.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"uploads-probe-13-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"uploads-probe-13-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"uploads-probe-13-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-13-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:28:\"uploads-probe-13-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}'),
(371,80,'_wp_attached_file','2026/08/uploads-probe-14.jpg'),
(372,80,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2026/08/uploads-probe-14.jpg\";s:8:\"filesize\";i:22639;s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"uploads-probe-14-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"uploads-probe-14-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"uploads-probe-14-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"uploads-probe-14-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"card\";a:4:{s:4:\"file\";s:28:\"uploads-probe-14-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:13:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}s:3:\"alt\";s:0:\"\";}}');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `type_status_author` (`post_type`,`post_status`,`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES
(1,1,'2026-08-20 08:17:10','2026-08-20 08:17:10','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2026-08-20 08:17:10','2026-08-20 08:17:10','',0,'https://foehn-demo.ddev.site/?p=1',0,'post','',1),
(2,1,'2026-08-20 08:17:10','2026-08-20 08:17:10','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"https://foehn-demo.ddev.site/wp/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2026-08-20 08:17:10','2026-08-20 08:17:10','',0,'https://foehn-demo.ddev.site/?page_id=2',0,'page','',0),
(3,1,'2026-08-20 08:17:10','2026-08-20 08:17:10','<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: https://foehn-demo.ddev.site.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n','Privacy Policy','','draft','closed','open','','privacy-policy','','','2026-08-20 08:17:10','2026-08-20 08:17:10','',0,'https://foehn-demo.ddev.site/?page_id=3',0,'page','',0),
(4,0,'2026-08-20 08:17:15','2026-08-20 08:17:15','','Modern white corridor','','inherit','open','closed','','modern-white-corridor','','','2026-08-20 08:17:15','2026-08-20 08:17:15','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/corridors-01-LCJ9iOli-uE.jpg',0,'attachment','image/jpeg',0),
(5,0,'2026-08-20 08:17:17','2026-08-20 08:17:17','','White ribbed facade','','inherit','open','closed','','white-ribbed-facade','','','2026-08-20 08:17:17','2026-08-20 08:17:17','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/corridors-02-9cU-HC5CND8.jpg',0,'attachment','image/jpeg',0),
(6,0,'2026-08-20 08:17:19','2026-08-20 08:17:19','','Window on murray building','','inherit','open','closed','','window-on-murray-building','','','2026-08-20 08:17:19','2026-08-20 08:17:19','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/corridors-03-hxi-yRxODNc.jpg',0,'attachment','image/jpeg',0),
(7,0,'2026-08-20 08:17:21','2026-08-20 08:17:21','','window on white wall mexico','','inherit','open','closed','','window-on-white-wall-mexico','','','2026-08-20 08:17:21','2026-08-20 08:17:21','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/corridors-04-WOSvM6tPHBQ.jpg',0,'attachment','image/jpeg',0),
(8,0,'2026-08-20 08:17:24','2026-08-20 08:17:24','','A decorative lettering','','inherit','open','closed','','a-decorative-lettering','','','2026-08-20 08:17:24','2026-08-20 08:17:24','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/corridors-05-zw07kVDaHPw.jpg',0,'attachment','image/jpeg',0),
(9,0,'2026-08-20 08:17:25','2026-08-20 08:17:25','','grayscale photogaphy of man sitting on concrete bench','','inherit','open','closed','','grayscale-photogaphy-of-man-sitting-on-concrete-bench','','','2026-08-20 08:17:25','2026-08-20 08:17:25','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/silhouettes-01-kX9lb7LUDWc-1.jpg',0,'attachment','image/jpeg',0),
(10,0,'2026-08-20 08:17:27','2026-08-20 08:17:27','','man walking on white surface','','inherit','open','closed','','man-walking-on-white-surface','','','2026-08-20 08:17:27','2026-08-20 08:17:27','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/silhouettes-02-x-Brii2QaM-1.jpg',0,'attachment','image/jpeg',0),
(11,0,'2026-08-20 08:17:28','2026-08-20 08:17:28','','A pregnant woman in silhouette holding her belly against a bright white background','','inherit','open','closed','','a-pregnant-woman-in-silhouette-holding-her-belly-against-a-bright-white-background','','','2026-08-20 08:17:28','2026-08-20 08:17:28','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/silhouettes-03-ZNVGL-Pcf74-1.jpg',0,'attachment','image/jpeg',0),
(12,0,'2026-08-20 08:17:31','2026-08-20 08:17:31','','Déjà Vu','','inherit','open','closed','','deja-vu','','','2026-08-20 08:17:31','2026-08-20 08:17:31','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/silhouettes-04-R9OueKOtGGU-1.jpg',0,'attachment','image/jpeg',0),
(13,0,'2026-08-20 08:17:33','2026-08-20 08:17:33','','withered tree surrounded with snow during daytime','','inherit','open','closed','','withered-tree-surrounded-with-snow-during-daytime','','','2026-08-20 08:17:33','2026-08-20 08:17:33','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/winter-01-Du41jIaI5Ww.jpg',0,'attachment','image/jpeg',0),
(14,0,'2026-08-20 08:17:35','2026-08-20 08:17:35','','pine tree covered with snow','','inherit','open','closed','','pine-tree-covered-with-snow','','','2026-08-20 08:17:35','2026-08-20 08:17:35','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/winter-02-4L-AyDJM-yM.jpg',0,'attachment','image/jpeg',0),
(15,0,'2026-08-20 08:17:37','2026-08-20 08:17:37','','Telephone pole','','inherit','open','closed','','telephone-pole','','','2026-08-20 08:17:37','2026-08-20 08:17:37','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/winter-03-kLwAv4D8eCs.jpg',0,'attachment','image/jpeg',0),
(16,0,'2026-08-20 08:17:39','2026-08-20 08:17:39','','no Title','','inherit','open','closed','','no-title','','','2026-08-20 08:17:39','2026-08-20 08:17:39','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/winter-04-UXLD2XHnWds.jpg',0,'attachment','image/jpeg',0),
(17,0,'2026-08-20 08:17:41','2026-08-20 08:17:41','','Grid notebook and Muji pen','','inherit','open','closed','','grid-notebook-and-muji-pen','','','2026-08-20 08:17:41','2026-08-20 08:17:41','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/objects-01-VBPzRgd7gfc.jpg',0,'attachment','image/jpeg',0),
(18,0,'2026-08-20 08:17:43','2026-08-20 08:17:43','','AirPods','','inherit','open','closed','','airpods','','','2026-08-20 08:17:43','2026-08-20 08:17:43','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/objects-02-NuOGFo4PudE.jpg',0,'attachment','image/jpeg',0),
(19,0,'2026-08-20 08:17:46','2026-08-20 08:17:46','','Pants on chair','','inherit','open','closed','','pants-on-chair','','','2026-08-20 08:17:46','2026-08-20 08:17:46','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/objects-03-vpOJwXxxpJ4.jpg',0,'attachment','image/jpeg',0),
(20,0,'2026-08-20 08:17:48','2026-08-20 08:17:48','','sugar block dropped on white cup with milk','','inherit','open','closed','','sugar-block-dropped-on-white-cup-with-milk','','','2026-08-20 08:17:48','2026-08-20 08:17:48','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/objects-04-sDeGlMAwcH4.jpg',0,'attachment','image/jpeg',0),
(21,0,'2026-08-20 08:17:50','2026-08-20 08:17:50','','A fencer\'s sword, close up','','inherit','open','closed','','a-fencers-sword-close-up','','','2026-08-20 08:17:50','2026-08-20 08:17:50','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/objects-05-34lqQKELTT4.jpg',0,'attachment','image/jpeg',0),
(22,0,'2026-08-20 08:17:52','2026-08-20 08:17:52','','monochrome floor osaka','','inherit','open','closed','','monochrome-floor-osaka','','','2026-08-20 08:17:52','2026-08-20 08:17:52','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/osaka-01-v2aoMh8xf0-1.jpg',0,'attachment','image/jpeg',0),
(23,0,'2026-08-20 08:17:54','2026-08-20 08:17:54','','If you would like to support my work, visit https://www.paypal.me/viktorforgacs (20% goes to charities)','','inherit','open','closed','','if-you-would-like-to-support-my-work-visit-https-www-paypal-me-viktorforgacs-20-goes-to-charities','','','2026-08-20 08:17:54','2026-08-20 08:17:54','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/osaka-02-fTvlM-68oZM-1.jpg',0,'attachment','image/jpeg',0),
(24,0,'2026-08-20 08:17:55','2026-08-20 08:17:55','','If you would like to support my work, visit https://www.paypal.me/viktorforgacs (20% goes to charities)','','inherit','open','closed','','if-you-would-like-to-support-my-work-visit-https-www-paypal-me-viktorforgacs-20-goes-to-charities-2','','','2026-08-20 08:17:55','2026-08-20 08:17:55','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/osaka-03-NECyhRpxGmU-1.jpg',0,'attachment','image/jpeg',0),
(25,0,'2026-08-20 08:17:57','2026-08-20 08:17:57','','osaka-04-jZJn74JUwSE-1','','inherit','open','closed','','osaka-04-jzjn74juwse-1','','','2026-08-20 08:17:57','2026-08-20 08:17:57','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/osaka-04-jZJn74JUwSE-1.jpg',0,'attachment','image/jpeg',0),
(26,0,'2026-08-20 08:18:00','2026-08-20 08:18:00','','Statue of Liberty','','inherit','open','closed','','statue-of-liberty','','','2026-08-20 08:18:00','2026-08-20 08:18:00','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/osaka-05-tFu9EMyR87E-1.jpg',0,'attachment','image/jpeg',0),
(27,0,'2026-08-20 08:18:02','2026-08-20 08:18:02','','Water Journal is a bi-annual publication exploring the beauty and complexity of all things water. Dedicated to the experience and cultural significance of water, it exists to tell honest stories, whether it’s of a personal matter or on a global scale. Featured essay: Kristina Chelberg','','inherit','open','closed','','water-journal-is-a-bi-annual-publication-exploring-the-beauty-and-complexity-of-all-things-water-dedicated-to-the-experience-and-cultural-significance-of-water-it-exists-to-tell-honest-stories-whet','','','2026-08-20 08:18:02','2026-08-20 08:18:02','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/editions-01-RWRnUMWtOWk-1.jpg',0,'attachment','image/jpeg',0),
(28,0,'2026-08-20 08:18:04','2026-08-20 08:18:04','','Water Journal is a bi-annual publication exploring the beauty and complexity of all things water. Dedicated to the experience and cultural significance of water, it exists to tell honest stories, whether it’s of a personal matter or on a global scale. Cover photography: Troy Moth','','inherit','open','closed','','water-journal-is-a-bi-annual-publication-exploring-the-beauty-and-complexity-of-all-things-water-dedicated-to-the-experience-and-cultural-significance-of-water-it-exists-to-tell-honest-stories-whet-2','','','2026-08-20 08:18:04','2026-08-20 08:18:04','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/editions-02-EbuaKnSm8Zw-1.jpg',0,'attachment','image/jpeg',0),
(29,0,'2026-08-20 08:18:05','2026-08-20 08:18:05','','Wallpapers “Black Serie” from anckor.com','','inherit','open','closed','','wallpapers-black-serie-from-anckor-com','','','2026-08-20 08:18:05','2026-08-20 08:18:05','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/editions-03-HY3l4IeOc3E-1.jpg',0,'attachment','image/jpeg',0),
(30,0,'2026-08-20 08:18:07','2026-08-20 08:18:07','','a black and white photo of a bunch of flowers','','inherit','open','closed','','a-black-and-white-photo-of-a-bunch-of-flowers','','','2026-08-20 08:18:07','2026-08-20 08:18:07','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/editions-04-YIPSx8PFi9s-1.jpg',0,'attachment','image/jpeg',0),
(31,0,'2026-08-20 08:18:09','2026-08-20 08:18:09','','If you like my work and you\'d like to support me, you can also consider a donation > http://www.paypal.me/helloimnik. Thank you 😌\n\nThere’s a derelict factory grounds very close to me, this wall has been erected since the car park was closed to stop cars entering. I love the engraved arrow, rather than the usual, obvious plastic signage. I’m always looking for direction, this photo reminds me that every way is a way.','','inherit','open','closed','','if-you-like-my-work-and-youd-like-to-support-me-you-can-also-consider-a-donation-http-www-paypal-me-helloimnik-thank-you-%f0%9f%98%8ctheres-a-derelict-factory-grounds-very-close-to-m','','','2026-08-20 08:18:09','2026-08-20 08:18:09','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/editions-05-MAgPyHRO0AA-1.jpg',0,'attachment','image/jpeg',0),
(32,0,'2026-08-20 08:18:11','2026-08-20 08:18:11','','greed.','','inherit','open','closed','','greed','','','2026-08-20 08:18:11','2026-08-20 08:18:11','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/studio-01-VBWWscZtszY-1.jpg',0,'attachment','image/jpeg',0),
(33,0,'2026-08-20 08:18:14','2026-08-20 08:18:14','','Captured in Morro Bay cruisin single stag','','inherit','open','closed','','captured-in-morro-bay-cruisin-single-stag','','','2026-08-20 08:18:14','2026-08-20 08:18:14','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/studio-02-cmt3JdS5MC4-1.jpg',0,'attachment','image/jpeg',0),
(34,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>The series began with a delay: two hours waiting in a lobby, and nothing to look at but a corridor. Office buildings treat their circulation as plumbing — no intention, no display. That is exactly what makes them photogenic. The light is blunt, the lines are clean, and nothing has been arranged to be seen.</p>\n<p>Shot on film, square negatives cropped to 4:3 at the print stage.</p>','Corridors','Six months spent in the circulation spaces of office buildings, photographing what nobody looks at on the way through.','publish','closed','closed','','corridors','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/corridors/',1,'project','',0),
(35,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Is a portrait without a face still a portrait? The series started as a constraint on a commission — a client who wanted nobody identifiable — and carried on long after the work was delivered.</p>\n<p>Every frame is a single exposure. No outline has been retouched.</p>','Silhouettes','Bodies against the light, reduced to an outline. What is left of a portrait once you take the face away.','publish','closed','closed','','silhouettes','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/silhouettes/',2,'project','',0),
(36,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Snow does to a landscape what black and white does to a photograph: it removes everything that is not structure. A single tree in a snowed field stops being a tree and becomes a stroke.</p>\n<p>Made over three winters, always in the same place.</p>','Winter','The Vosges under snow, where the landscape loses its mid-tones and keeps only two values.','publish','closed','closed','','winter','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/winter/',3,'project','',0),
(37,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>A publishing commission that asked for “neutral” images to sit alongside a text. The brief said: nothing that tells a story. It turned out to be impossible to honour.</p>','Objects','Contemporary still life: whatever is lying on the table, lit as though it were a subject.','publish','closed','closed','','objects','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/objects/',4,'project','',0),
(38,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Not understanding a city\'s language is the best way to see its shape. With the text gone you are left looking at surfaces, at floors, at the way light falls between two buildings.</p>','Osaka','Three weeks walking a city whose signs I could not read.','publish','closed','closed','','osaka','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/osaka/',5,'project','',0),
(39,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Photographing printed paper means solving one simple, tedious problem: the white of the paper is never the white of the backdrop. The series documents a method as much as a set of objects.</p>','Editions','Commissioned work for independent publishers: books, journals, stationery.','publish','closed','closed','','editions','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/editions/',6,'project','',0),
(40,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','Home','','publish','closed','closed','','home','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/home/',0,'page','',0),
(41,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>I have been photographing since 2016, first for architects, now mostly for publishers and institutions. My personal work and my commissioned work look much the same: same equipment, same light, same refusal of colour.</p>\n<p>Black and white is not nostalgia. It is a way of removing a variable — the colour of a wall, the colour of a sky — so that only structure and light are left. On a building site or in a studio it comes down to the same question: where is the line, and where is the light coming from?</p>\n<h2>Services</h2>\n<p>Architectural reportage, editorial portraiture, still life and artwork reproduction. Prints available on request, in numbered limited editions.</p>\n<h2>Selected clients</h2>\n<p>Water Journal, Grille Editions, Contrejour Review, and several architecture practices across the Rhine valley.</p>','About','Independent photographer, Strasbourg. Architecture, portraiture and still life, mostly on black and white film.','publish','closed','closed','','about','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/about/',0,'page','',0),
(42,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','She shot four issues for us. The images hold together without ever repeating themselves, which is exactly what you ask of a series.','Water Journal','','publish','closed','closed','','water-journal','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/testimonial/water-journal/',0,'testimonial','',0),
(43,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','An impossible brief, met anyway. She argues with the constraints before the shoot, never after.','Grille Editions','','publish','closed','closed','','grille','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/testimonial/grille/',0,'testimonial','',0),
(44,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','The faceless portrait became the cover of the issue. We had not commissioned it.','Contrejour Review','','publish','closed','closed','','contrejour','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/testimonial/contrejour/',0,'testimonial','',0),
(50,0,'2026-08-20 08:19:58','2026-08-20 08:19:58','','Uploads probe','','inherit','open','closed','','uploads-probe','','','2026-08-20 08:19:58','2026-08-20 08:19:58','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/uploads-probe.jpg',0,'attachment','image/jpeg',0),
(51,0,'2026-08-20 08:25:45','2026-08-20 08:25:45','','Uploads probe','','inherit','open','closed','','uploads-probe-2','','','2026-08-20 08:25:45','2026-08-20 08:25:45','',0,'https://foehn-demo.ddev.site:9443/media/uploads/2026/08/uploads-probe.jpg',0,'attachment','image/jpeg',0),
(52,0,'2026-08-20 08:32:19','2026-08-20 08:32:19','','Uploads probe','','inherit','open','closed','','uploads-probe-3','','','2026-08-20 08:32:19','2026-08-20 08:32:19','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-1.jpg',0,'attachment','image/jpeg',0),
(53,0,'2026-08-20 08:33:07','2026-08-20 08:33:07','','Uploads probe','','inherit','open','closed','','uploads-probe-4','','','2026-08-20 08:33:07','2026-08-20 08:33:07','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-2.jpg',0,'attachment','image/jpeg',0),
(54,0,'2026-08-20 08:37:00','2026-08-20 08:37:00','','Uploads probe','','inherit','open','closed','','uploads-probe-5','','','2026-08-20 08:37:00','2026-08-20 08:37:00','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe.jpg',0,'attachment','image/jpeg',0),
(55,0,'2026-08-20 08:39:53','2026-08-20 08:39:53','','Uploads probe','','inherit','open','closed','','uploads-probe-6','','','2026-08-20 08:39:53','2026-08-20 08:39:53','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-1.jpg',0,'attachment','image/jpeg',0),
(56,0,'2026-08-20 08:54:11','2026-08-20 08:54:11','','Uploads probe','','inherit','open','closed','','uploads-probe-7','','','2026-08-20 08:54:11','2026-08-20 08:54:11','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-3.jpg',0,'attachment','image/jpeg',0),
(57,0,'2026-08-20 09:13:00','2026-08-20 09:13:00','','Uploads probe','','inherit','open','closed','','uploads-probe-8','','','2026-08-20 09:13:00','2026-08-20 09:13:00','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-4.jpg',0,'attachment','image/jpeg',0),
(58,0,'2026-08-20 09:15:28','2026-08-20 09:15:28','','Uploads probe','','inherit','open','closed','','uploads-probe-9','','','2026-08-20 09:15:28','2026-08-20 09:15:28','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-5.jpg',0,'attachment','image/jpeg',0),
(59,0,'2026-08-20 09:31:51','2026-08-20 09:31:51','','Uploads probe','','inherit','open','closed','','uploads-probe-10','','','2026-08-20 09:31:51','2026-08-20 09:31:51','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-6.jpg',0,'attachment','image/jpeg',0),
(60,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>The series began with a delay: two hours waiting in a lobby, and nothing to look at but a corridor. Office buildings treat their circulation as plumbing — no intention, no display. That is exactly what makes them photogenic. The light is blunt, the lines are clean, and nothing has been arranged to be seen.</p>\n<p>Shot on film, square negatives cropped to 4:3 at the print stage.</p>','Corridors','Six months spent in the circulation spaces of office buildings, photographing what nobody looks at on the way through.','inherit','closed','closed','','34-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',34,'https://foehn-demo.ddev.site/?p=60',0,'revision','',0),
(61,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Is a portrait without a face still a portrait? The series started as a constraint on a commission — a client who wanted nobody identifiable — and carried on long after the work was delivered.</p>\n<p>Every frame is a single exposure. No outline has been retouched.</p>','Silhouettes','Bodies against the light, reduced to an outline. What is left of a portrait once you take the face away.','inherit','closed','closed','','35-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',35,'https://foehn-demo.ddev.site/?p=61',0,'revision','',0),
(62,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Snow does to a landscape what black and white does to a photograph: it removes everything that is not structure. A single tree in a snowed field stops being a tree and becomes a stroke.</p>\n<p>Made over three winters, always in the same place.</p>','Winter','The Vosges under snow, where the landscape loses its mid-tones and keeps only two values.','inherit','closed','closed','','36-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',36,'https://foehn-demo.ddev.site/?p=62',0,'revision','',0),
(63,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>A publishing commission that asked for “neutral” images to sit alongside a text. The brief said: nothing that tells a story. It turned out to be impossible to honour.</p>','Objects','Contemporary still life: whatever is lying on the table, lit as though it were a subject.','inherit','closed','closed','','37-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',37,'https://foehn-demo.ddev.site/?p=63',0,'revision','',0),
(64,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Not understanding a city\'s language is the best way to see its shape. With the text gone you are left looking at surfaces, at floors, at the way light falls between two buildings.</p>','Osaka','Three weeks walking a city whose signs I could not read.','inherit','closed','closed','','38-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',38,'https://foehn-demo.ddev.site/?p=64',0,'revision','',0),
(65,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>Photographing printed paper means solving one simple, tedious problem: the white of the paper is never the white of the backdrop. The series documents a method as much as a set of objects.</p>','Editions','Commissioned work for independent publishers: books, journals, stationery.','inherit','closed','closed','','39-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',39,'https://foehn-demo.ddev.site/?p=65',0,'revision','',0),
(66,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','Home','','inherit','closed','closed','','40-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',40,'https://foehn-demo.ddev.site/?p=66',0,'revision','',0),
(67,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','<p>I have been photographing since 2016, first for architects, now mostly for publishers and institutions. My personal work and my commissioned work look much the same: same equipment, same light, same refusal of colour.</p>\n<p>Black and white is not nostalgia. It is a way of removing a variable — the colour of a wall, the colour of a sky — so that only structure and light are left. On a building site or in a studio it comes down to the same question: where is the line, and where is the light coming from?</p>\n<h2>Services</h2>\n<p>Architectural reportage, editorial portraiture, still life and artwork reproduction. Prints available on request, in numbered limited editions.</p>\n<h2>Selected clients</h2>\n<p>Water Journal, Grille Editions, Contrejour Review, and several architecture practices across the Rhine valley.</p>','About','Independent photographer, Strasbourg. Architecture, portraiture and still life, mostly on black and white film.','inherit','closed','closed','','41-revision-v1','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',41,'https://foehn-demo.ddev.site/?p=67',0,'revision','',0),
(68,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','Projects','','publish','closed','closed','','projects','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects/',0,'nav_menu_item','',0),
(69,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','About','','publish','closed','closed','','about','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/about/',2,'nav_menu_item','',0),
(70,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','Projects','','publish','closed','closed','','projects-2','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/projects-2/',0,'nav_menu_item','',0),
(71,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','About','','publish','closed','closed','','about-2','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/about-2/',2,'nav_menu_item','',0),
(72,0,'2026-08-20 09:59:09','2026-08-20 09:59:09','','Legal','','publish','closed','closed','','legal','','','2026-08-20 09:59:09','2026-08-20 09:59:09','',0,'https://foehn-demo.ddev.site/legal/',0,'nav_menu_item','',0),
(73,0,'2026-08-20 10:03:47','2026-08-20 10:03:47','','Uploads probe','','inherit','open','closed','','uploads-probe-11','','','2026-08-20 10:03:47','2026-08-20 10:03:47','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-7.jpg',0,'attachment','image/jpeg',0),
(74,0,'2026-08-20 10:04:02','2026-08-20 10:04:02','','Uploads probe','','inherit','open','closed','','uploads-probe-12','','','2026-08-20 10:04:02','2026-08-20 10:04:02','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-8.jpg',0,'attachment','image/jpeg',0),
(75,0,'2026-08-20 10:04:28','2026-08-20 10:04:28','','Uploads probe','','inherit','open','closed','','uploads-probe-13','','','2026-08-20 10:04:28','2026-08-20 10:04:28','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-9.jpg',0,'attachment','image/jpeg',0),
(76,0,'2026-08-20 10:04:50','2026-08-20 10:04:50','','Uploads probe','','inherit','open','closed','','uploads-probe-14','','','2026-08-20 10:04:50','2026-08-20 10:04:50','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-10.jpg',0,'attachment','image/jpeg',0),
(77,0,'2026-08-20 10:05:08','2026-08-20 10:05:08','','Uploads probe','','inherit','open','closed','','uploads-probe-15','','','2026-08-20 10:05:08','2026-08-20 10:05:08','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-11.jpg',0,'attachment','image/jpeg',0),
(78,0,'2026-08-20 10:08:59','2026-08-20 10:08:59','','Uploads probe','','inherit','open','closed','','uploads-probe-16','','','2026-08-20 10:08:59','2026-08-20 10:08:59','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-12.jpg',0,'attachment','image/jpeg',0),
(79,0,'2026-08-20 10:09:48','2026-08-20 10:09:48','','Uploads probe','','inherit','open','closed','','uploads-probe-17','','','2026-08-20 10:09:48','2026-08-20 10:09:48','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-13.jpg',0,'attachment','image/jpeg',0),
(80,0,'2026-08-20 10:10:30','2026-08-20 10:10:30','','Uploads probe','','inherit','open','closed','','uploads-probe-18','','','2026-08-20 10:10:30','2026-08-20 10:10:30','',0,'https://foehn-demo.ddev.site/wp-content/uploads/2026/08/uploads-probe-14.jpg',0,'attachment','image/jpeg',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES
(1,1,0),
(34,2,0),
(35,3,0),
(36,4,0),
(37,5,0),
(38,6,0),
(39,5,0),
(68,7,0),
(69,7,0),
(70,8,0),
(71,8,0),
(72,9,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES
(1,1,'category','',0,1),
(2,2,'project_category','',0,1),
(3,3,'project_category','',0,1),
(4,4,'project_category','',0,1),
(5,5,'project_category','',0,2),
(6,6,'project_category','',0,1),
(7,7,'nav_menu','',0,2),
(8,8,'nav_menu','',0,2),
(9,9,'nav_menu','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES
(1,'Uncategorized','uncategorized',0),
(2,'Architecture','architecture',0),
(3,'Portrait','portrait',0),
(4,'Landscape','landscape',0),
(5,'Still life','still-life',0),
(6,'Documentary','documentary',0),
(7,'Demo header','demo-header',0),
(8,'Demo footer','demo-footer',0),
(9,'Demo legal','demo-legal',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES
(1,1,'nickname','admin'),
(2,1,'first_name',''),
(3,1,'last_name',''),
(4,1,'description',''),
(5,1,'rich_editing','true'),
(6,1,'syntax_highlighting','true'),
(7,1,'infinite_scrolling','true'),
(8,1,'comment_shortcuts','false'),
(9,1,'admin_color','modern'),
(10,1,'use_ssl','0'),
(11,1,'show_admin_bar_front','true'),
(12,1,'locale',''),
(13,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
(14,1,'wp_user_level','10'),
(15,1,'dismissed_wp_pointers',''),
(16,1,'show_welcome_panel','1');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES
(1,'admin','$wp$2y$12$fwOV4R9DW/nsct4txN7rN.xGcsZ06aSiP/yaiHR1M7gBM/Q5QDdoy','admin','admin@example.com','https://foehn-demo.ddev.site/wp','2026-08-20 08:17:10','',0,'admin');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-20 12:12:07
